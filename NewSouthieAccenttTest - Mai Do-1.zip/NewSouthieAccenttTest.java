/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import newaccent.NewSouthieAccentt;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Mai Do
 */
public class NewSouthieAccenttTest {
    



    /**
     * Test of main method, of class NewSouthieAccentt.
     */


    /**
     * Test of isVowel method, of class NewSouthieAccentt.
     */
  
    @Test
    public void testConvert() {
        System.out.println("convert");

        
        assertEquals("wicked innovative", NewSouthieAccentt.convert("Very innovative"));
        assertEquals("doowah", NewSouthieAccentt.convert("door"));
        assertEquals("miyah", NewSouthieAccentt.convert("mir"));
        assertEquals("hahboh", NewSouthieAccentt.convert("harbor"));
        assertEquals("tunar", NewSouthieAccentt.convert("tuna"));
        
        
    }

    /**
     * Test of ReplaceRwithWah method, of class NewSouthieAccentt.
     */
    @Test
    public void testReplaceRwithH() {
   
        System.out.println("testReplaceRwithH");
        assertEquals("hohroh", NewSouthieAccentt.ReplaceRwithH("horror"));
        assertEquals("hahboh", NewSouthieAccentt.ReplaceRwithH("harbor"));
        assertEquals("believeh", NewSouthieAccentt.ReplaceRwithH("believer"));
        assertEquals("Biebeh", NewSouthieAccentt.ReplaceRwithH("Bieber"));
     
    }

    
    @Test
    public void AppendRafterA() {
   
        System.out.println("testAppendRafterA");
        assertEquals("Nanar", NewSouthieAccentt.AppendRafterA("Nana"));
        assertEquals("lizar", NewSouthieAccentt.AppendRafterA("liza"));
        assertEquals("geeraar", NewSouthieAccentt.AppendRafterA("geeraa"));
        assertEquals("momar", NewSouthieAccentt.AppendRafterA("moma"));
     
    }
   
}