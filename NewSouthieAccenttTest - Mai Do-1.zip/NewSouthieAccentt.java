package newaccent;

/*
Mai Nhu Do 
03/25/2018
tuf96473@temple.edu
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import java.io.IOException;
import java.util.Scanner;
import java.io.PrintStream;
import java.io.BufferedReader;

import java.io.InputStreamReader;

/**
 *
 * @author Mai Do
 */
public class NewSouthieAccentt {
    boolean inDialogue = false;
    /**
     * @param args the command line arguments
     */
    
   
            
    public static void main(String args[]) throws FileNotFoundException, IOException {
        
        
        BufferedReader br = null;
        String result = null;
   
        Scanner entry; //iterate through a loop and append every method in the loop
 
        String out = "";
        try {
            System.out.print("Enter the file name with extension : ");
        
            entry = new Scanner(System.in);

            br = new BufferedReader(new InputStreamReader(new FileInputStream(entry.nextLine()), "UTF-8"));//unicode dash
            File outputfile = new File("output.txt");
            PrintStream writestream = new PrintStream(outputfile);
            NewSouthieAccentt temp = new NewSouthieAccentt();
      
            String line;
            while ((line = br.readLine()) != null) {
                              
                String newLine = temp.quoteonly(line); 
                out += newLine + "\r\n";// crucial method to go down a line 
               
            }
     
            //System.out.println(out);
            writestream.println(out);
            
        } catch (FileNotFoundException ex) {
            
        }
    }
    public String quoteonly(String k) {
            String findquote = "";
            
            int indexofquote = k.toLowerCase().indexOf("\"");
        String currentstring = k;
        while(currentstring.contains("\"")) {
            if (inDialogue) {
                inDialogue = false;
                findquote += convert(currentstring.substring(0, indexofquote)) ;
        } else {
                inDialogue = true;
                 findquote += currentstring.substring(0, indexofquote);
              
             }
            findquote += '"'; // for the previous quote doesn't have a "
            // find the abter quote, remaining quote 
            currentstring = currentstring.substring(indexofquote + 1);
            indexofquote = currentstring.toLowerCase().indexOf("\"");
        }
        
        if (inDialogue) {
                findquote += convert(currentstring);
                
        } else {
                findquote += currentstring;

            }
        
        return findquote;
        
        
    }
     public static boolean isVowel(char f) {
        char c = Character.toLowerCase(f);
        if (c == 'a' || c == 'i' || c == 'u' || c == 'e' || c == 'o') {
            return true;
        }
        return false;
    
    }

//Find ending and beginning of a quote
     
//passed a string word and return the word into southern accent
    public static String convert(String line) {
        //String line = line;
        //if (line.contains("very")) {
        //   line = veryToWicked(line);
        //}
        
        line = veryToWicked(line);
        
        line = ReplaceRwithWah(line);
       
        line = ReplaceWithYah(line);
      
        line = ReplaceRwithH(line);
       
        line = AppendRafterA(line);
      
        return line ; 
    }
//replace ee or i with yah       
 

    public static String ReplaceRwithWah(String k) {
        String DoorWah = ""; 
        
        if (k.length() > 2){
       
            if (k.toLowerCase().endsWith("oor")) {
                //System.out.println(k.substring(0, k.length() - 1));
                DoorWah = k.substring(0, k.length() - 1) + "wah";
                return DoorWah ;
            }
        }
        
        
       return k ;

    }

 
    public static String ReplaceWithYah(String k) {
        String DeerYah = "";    //String out5 = k
        if (k.length() > 1) {
        
            //if (k.contains("ee" || k.contains('i')) { //
            if (k.toLowerCase().endsWith("eer") || k.toLowerCase().endsWith("ir")){
                
                   DeerYah += k.substring(0, k.length() - 1) + "yah";
                   
                   return DeerYah ;
            }               
    
        }
        return k ;  // if the first if is true, return k right away, no need else
      
    }
        
   
// attach the printstem to ou.print(printsream) // whwhatever you declare your printstream
    
// DELETE and REBUILD and COMMENT 
    // r following a vowel, replace 'r' with 'h'
    public static String ReplaceRwithH(String k) {
        //String RwithH = k; 
        //we replace r at the end by h
        if (k.contains("very")) {
            k = veryToWicked(k);
        }
        
        String RwithH = k;
        if (k.length() >= 2){ 
            if (k.toLowerCase().endsWith("ar") || k.toLowerCase().endsWith("er") || k.toLowerCase().endsWith("or") || k.toLowerCase().endsWith("ur")){
                RwithH = RwithH.substring(0,RwithH.length()-1) + 'h';
         
            }
            
        for (int i = 0; i < k.length() - 1; i++) {
            //System.out.println(RwithH);

            if (k.toLowerCase().charAt(i) == 'r') {
                if (i > 0 && isVowel(k.toLowerCase().charAt(i-1))) {
                    //System.out.println(RwithH.charAt(i));
                    RwithH = RwithH.substring(0,i) + 'h' + RwithH.substring(i+1, RwithH.length());
 
                } 
            }
     
        }
    }
        return RwithH ; // RwithH = k so if it does not satisfy condition, we
        // won't change anything and return k
  
    }
    // append an r
    public static String AppendRafterA(String k) {
        String AppendR = k;
        if (k.length() > 1) {
            //we don't iterate through a string'//

            if (k.toLowerCase().endsWith("a")) {
                AppendR += "r";
            }
        }

        return AppendR ;
    }
    
    

    public static String veryToWicked(String s) {
        String newStr = s;
        for (int i = 0; i < newStr.length();i++){
            if (newStr.toLowerCase().indexOf("very") == i){
                newStr = newStr.substring(0,i)+ "wicked" + newStr.substring(i+4);
            }
        }
        
        /*if (newStr.toLowerCase().contains(("very "))) {
        
        }
        while (newStr.toLowerCase().contains("very")) {
            int index = newStr.toLowerCase().indexOf("very");
            if (index == 0) {
                String temp = "Wicked" + newStr.substring(index + 4, newStr.length());
                newStr = temp;
            }
            else if (index + 4 < newStr.length() - 1) {
                //System.out.println(newStr);
                newStr = newStr.substring(0,index) + "wicked" + newStr.substring(index + 4, newStr.length());
            } else {
                newStr = newStr.substring(0,index) + "wicked";
            } 
        }
        //if (s.equalsIgnoreCase("very")) {
        //    return "wicked";
        //} else {
        //    return s ;
        //} */
        return newStr;
}
}

   